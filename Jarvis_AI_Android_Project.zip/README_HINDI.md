# JARVIS AI — Android starter project

यह एक वास्तविक Android Studio/AndroidIDE project है, तैयार APK नहीं। ZIP खोलकर APK बनाया जा सकता है। इसमें:
- Hindi/English speech input और Android Text-to-Speech voice output
- Gemini API से AI जवाब; Google Search grounding tool का अनुरोध
- YouTube खोलना, Back/Home, accessibility के जरिए दिखाई दे रहे Play/Pause/Search controls पर सीमित कार्रवाई
- Accessibility service द्वारा स्क्रीन के visible text को पढ़ने की सुविधा
- Draggable floating mini-ball (J)
- Experimental “Hey Jarvis” foreground microphone listener

## जरूरी बातें / सीमाएं
1. **API key:** Gemini API key के बिना AI सवालों के जवाब नहीं देगा। Google AI Studio से अपनी key लें और app में डालें। Key इसी फोन के app preferences में रखी जाती है; इसे किसी के साथ साझा न करें।
2. **Screen control:** Android Settings → Accessibility → Downloaded/Installed apps → Jarvis AI को ON करें। Accessibility permission बहुत शक्तिशाली है; केवल अपने बनाए/विश्वसनीय app को दें। यह हर app या हर button पर काम करने की गारंटी नहीं देता।
3. **Floating ball:** “Allow floating window permission” दबाकर अनुमति दें, फिर Enable floating mini ball दबाएं। हटाने के लिए Remove floating mini ball दबाएं।
4. **Hey Jarvis:** यह demo Android SpeechRecognizer को लगातार restart करता है। यह असली low-power hotword engine नहीं है। फोन लॉक/Doze/OEM battery manager इसे रोक सकते हैं; microphone foreground notification दिखेगी और Android 14+ में microphone permission/foreground restrictions लागू हैं। बंद/पूरी तरह powered-off फोन में कोई app सुन नहीं सकता।
5. **फोन बंद होने पर:** फोन powered off हो तो assistant नहीं चल सकता। Screen off/locked अवस्था में भी hotword की गारंटी नहीं है।
6. **Privacy:** Accessibility service स्क्रीन के text को local SharedPreferences में रखती है। AI को केवल वही prompt भेजा जाता है जो आप बोलते/लिखते हैं; screen text अपने-आप cloud पर नहीं भेजा जाता।

## फोन से APK कैसे बनाएं

### विकल्प A — AndroidIDE (फोन पर)
1. AndroidIDE install करें (विश्वसनीय official source से)।
2. ZIP को extract करें।
3. AndroidIDE में extracted `JarvisAssistantAndroid` folder को Open Project करें।
4. Gradle sync होने दें; SDK 35 / compatible build tools install करने को कहे तो install करें।
5. Build → Assemble/Build APK चुनें।
6. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

### विकल्प B — GitHub Actions (cloud build)
1. ZIP extract करके पूरा project अपने GitHub repository में upload करें।
2. `.github/workflows/android.yml` workflow मौजूद है।
3. GitHub → Actions → Android APK build → Run workflow।
4. सफल build के बाद `jarvis-debug-apk` artifact download करें और फोन में install करें।

## First run
- Microphone permission allow करें।
- Gemini API key डालकर Save API key करें।
- Overlay permission दें और floating ball enable करें।
- Screen reading/control के लिए Accessibility service manually enable करें।
- “Speak” से सवाल पूछें या text लिखकर “Ask Jarvis” दबाएं।

## Supported command examples
- “YouTube kholo”
- “Back”
- “Home”
- “Screen par kya hai”
- “Search for cats” (जब active screen पर editable search field मौजूद हो)
- “Play” / “Pause” (जब visible accessible button का label Play/Pause हो)

यह starter है, production-grade पूर्ण phone-control system नहीं। Android security boundaries, app-specific UI, permissions, battery optimization और OEM restrictions के कारण हर command हर फोन पर नहीं चलेगी।
