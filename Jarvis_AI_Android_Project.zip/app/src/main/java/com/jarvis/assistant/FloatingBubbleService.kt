package com.jarvis.assistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView

class FloatingBubbleService : Service() {
    private var window: WindowManager? = null
    private var bubble: View? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null) {
            window = getSystemService(WINDOW_SERVICE) as WindowManager
            val tv = TextView(this).apply {
                text = "J"
                textSize = 22f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(0xFF087EA4.toInt())
                    setStroke(3, 0xFF8DEBFF.toInt())
                }
                elevation = 12f
            }
            val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                       else WindowManager.LayoutParams.TYPE_PHONE
            val params = WindowManager.LayoutParams(58, 58, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.END
                x = 18; y = 260
            }
            var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
            tv.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                    MotionEvent.ACTION_UP -> {
                        if (kotlin.math.abs(event.rawX-downX) < 12 && kotlin.math.abs(event.rawY-downY) < 12) {
                            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(i)
                        }
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (downX-event.rawX).toInt()
                        params.y = startY + (event.rawY-downY).toInt()
                        window?.updateViewLayout(tv, params); true
                    }
                    else -> false
                }
            }
            bubble = tv
            window?.addView(tv, params)
        }
        return START_STICKY
    }
    override fun onDestroy() { bubble?.let { window?.removeView(it) }; bubble = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
