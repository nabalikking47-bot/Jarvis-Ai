package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.Context
import android.os.Bundle
import java.util.Locale

class JarvisAccessibilityService : AccessibilityService() {
    companion object { var instance: JarvisAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        val lines = mutableListOf<String>()
        collectText(root, lines)
        getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit()
            .putString("screen_text", lines.distinct().joinToString(". ").take(5000)).apply()
    }
    private fun collectText(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null || out.size > 150) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) collectText(node.getChild(i), out)
    }

    fun runScreenCommand(command: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = command.lowercase(Locale.ROOT)
        if (q.contains("back")) return performGlobalAction(GLOBAL_ACTION_BACK)
        if (q.contains("play")) {
            val node = findNode(root) { (it.text?.toString() + " " + it.contentDescription?.toString()).contains("play", true) }
            if (node != null) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        if (q.contains("pause")) {
            val node = findNode(root) { (it.text?.toString() + " " + it.contentDescription?.toString()).contains("pause", true) }
            if (node != null) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        if (q.contains("search")) {
            val term = command.substringAfter("search", "").substringAfter("for", "").trim()
            val edit = findNode(root) { it.className?.toString()?.contains("EditText") == true && it.isEditable }
            if (edit != null && term.isNotBlank()) {
                edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, term)
                })
                edit.performAction(AccessibilityNodeInfo.ACTION_IME_ENTER)
                return true
            }
        }
        return false
    }

    private fun findNode(node: AccessibilityNodeInfo?, test: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (node == null) return null
        if (test(node)) return node
        for (i in 0 until node.childCount) {
            val found = findNode(node.getChild(i), test)
            if (found != null) return found
        }
        return null
    }
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }
}
