package com.jarvis.assistant

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var question: EditText
    private lateinit var apiKey: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val prefs by lazy { getSharedPreferences("jarvis", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        requestAudioPermission()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 20)
            setBackgroundColor(0xFF071421.toInt())
        }
        val heading = TextView(this).apply {
            text = "J.A.R.V.I.S"
            textSize = 30f
            setTextColor(0xFF55D6FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Online • Ready when you are"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8D7E8.toInt())
            setPadding(0, 8, 0, 18)
        }
        question = EditText(this).apply {
            hint = "Ask Jarvis or give a command…"
            setTextColor(-1); setHintTextColor(0xFF78909C.toInt())
            setSingleLine(false); minLines = 2
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFF142B3D.toInt())
        }
        apiKey = EditText(this).apply {
            hint = "Gemini API key (saved only on this phone)"
            setTextColor(-1); setHintTextColor(0xFF78909C.toInt())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("api_key", "") ?: "")
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF142B3D.toInt())
        }
        val saveKey = button("Save API key") {
            prefs.edit().putString("api_key", apiKey.text.toString().trim()).apply()
            say("API key saved on this device.")
        }
        val ask = button("Ask Jarvis") { submit(question.text.toString()) }
        val mic = button("🎙 Speak") { listenOnce() }
        val bubble = button("Enable floating mini ball") { enableBubble() }
        val removeBubble = button("Remove floating mini ball") {
            stopService(Intent(this, FloatingBubbleService::class.java))
            say("Floating button removed.")
        }
        val accessibility = button("Enable screen reading & control") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val wake = button("Experimental: start Hey Jarvis listener") {
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 12)
            }
            startForegroundService(Intent(this, WakeWordService::class.java))
            status.text = "Wake listener requested • keep its notification visible"
        }
        val stopWake = button("Stop wake listener") {
            stopService(Intent(this, WakeWordService::class.java))
            status.text = "Wake listener stopped"
        }
        val screen = button("Read current screen") {
            val txt = getSharedPreferences("jarvis", MODE_PRIVATE).getString("screen_text", "") ?: ""
            if (txt.isBlank()) say("I cannot read the current screen yet. Enable the accessibility service first.")
            else say(txt.take(900))
        }
        val overlayPermission = button("Allow floating window permission") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else say("Floating window permission is already allowed.")
        }
        listOf(heading, status, question, ask, mic, apiKey, saveKey, bubble, removeBubble,
            overlayPermission, accessibility, screen, wake, stopWake).forEach { layout.addView(it) }
        val note = TextView(this).apply {
            text = "Tip: Try “YouTube kholo”, “back”, “screen par kya hai”, or ask a general question. Screen control requires you to enable Android Accessibility settings."
            setTextColor(0xFF91AFC0.toInt()); textSize = 12f; setPadding(2, 14, 2, 4)
        }
        layout.addView(note)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun requestAudioPermission() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 10)
    }

    private fun listenOnce() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { say("Speech recognition is not available on this phone."); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening…" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Processing…" }
                override fun onError(error: Int) { status.text = "Speech error ($error). Tap Speak and try again." }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    question.setText(spoken); submit(spoken)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            })
        }
    }

    private fun submit(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return
        status.text = "Working…"
        val lower = text.lowercase(Locale.ROOT)
        when {
            lower.contains("youtube") && (lower.contains("open") || lower.contains("kholo") || lower.contains("chala")) -> {
                openPackage("com.google.android.youtube"); say("Opening YouTube."); return
            }
            lower == "back" || lower.contains("go back") || lower.contains("peeche") -> {
                JarvisAccessibilityService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                say("Going back."); return
            }
            lower.contains("home") || lower.contains("ghar") -> {
                JarvisAccessibilityService.instance?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                say("Going home."); return
            }
            lower.contains("screen") || lower.contains("samne kya") || lower.contains("kya dikh") -> {
                val s = prefs.getString("screen_text", "") ?: ""
                say(if (s.isBlank()) "Screen reading permission enable kijiye." else s.take(900)); return
            }
            lower.contains("play") || lower.contains("search") || lower.contains("pause") -> {
                val done = JarvisAccessibilityService.instance?.runScreenCommand(text) ?: false
                if (done) { say("Done."); return }
            }
        }
        askGemini(text)
    }

    private fun openPackage(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")))
    }

    private fun askGemini(prompt: String) {
        val key = prefs.getString("api_key", "") ?: ""
        if (key.isBlank()) { say("Please add your Gemini API key in the app first."); return }
        thread {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                }
                val body = JSONObject().put("contents", JSONArray().put(JSONObject()
                    .put("parts", JSONArray().put(JSONObject().put("text",
                        "You are Jarvis, a concise, helpful Hindi-English voice assistant. Answer clearly. User asks: $prompt")))))
                    .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val root = JSONObject(response)
                val answer = root.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)
                    ?.optString("text").orEmpty()
                runOnUiThread {
                    if (answer.isNotBlank()) say(answer)
                    else say("I could not get a response. Check your API key and internet connection.")
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { say("Network error. Please check internet and API key.") }
            }
        }
    }

    private fun say(message: String) {
        runOnUiThread {
            status.text = message
            if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
        }
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, FloatingBubbleService::class.java))
        say("Floating Jarvis button enabled.")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
