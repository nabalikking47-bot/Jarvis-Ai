package com.jarvis.assistant

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.*
import android.content.Context
import java.util.Locale

/*
 * Experimental continuous speech recognizer. Android/OEMs may stop recognition
 * when locked or under battery restrictions. This is NOT a guaranteed always-on
 * hotword engine. Use a dedicated offline wake-word SDK for production.
 */
class WakeWordService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    override fun onCreate() {
        super.onCreate()
        val channelId = "jarvis_wake"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Jarvis wake listener", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("Jarvis wake listener")
            .setContentText("Experimental microphone listener is active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(77, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        beginListening()
        return START_STICKY
    }
    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { listening = false }
                    override fun onError(error: Int) { listening = false; sr.postRestart() }
                    override fun onResults(results: android.os.Bundle?) {
                        listening = false
                        val phrase = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        if (phrase.contains("hey jarvis", true)) {
                            val launch = Intent(this@WakeWordService, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            startActivity(launch)
                        }
                        sr.postRestart()
                    }
                    override fun onPartialResults(partialResults: android.os.Bundle?) {
                        val phrase = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        if (phrase.contains("hey jarvis", true)) {
                            startActivity(Intent(this@WakeWordService, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                        }
                    }
                    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
                })
                val i = Intent(SpeechRecognizer.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                }
                sr.startListening(i)
            }
        } catch (_: Exception) {}
    }
    private fun SpeechRecognizer.postRestart() {
        android.os.Handler(mainLooper).postDelayed({ if (!listening) beginListening() }, 1200)
    }
    override fun onDestroy() { recognizer?.destroy(); stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
